#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 3142;
char ozw_version_string[] = "1.4-3142-g830f85e5-dirty";
