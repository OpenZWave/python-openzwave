#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 2504;
char ozw_version_string[] = "1.4-2504-gf1ae898-dirty";
