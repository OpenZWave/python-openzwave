#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 3102;
char ozw_version_string[] = "1.4-3102-g8bbcfb25-dirty";
