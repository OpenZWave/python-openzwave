#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 3311;
char ozw_version_string[] = "1.4-3311-g51da0ebc-dirty";
