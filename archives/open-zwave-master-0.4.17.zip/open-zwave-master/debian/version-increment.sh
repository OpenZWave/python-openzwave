#!/bin/bash
dch -v ${1} "new package"
dch -r "release"
