#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 3091;
char ozw_version_string[] = "1.4-3091-g613eb3b5-dirty";
