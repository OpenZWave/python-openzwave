#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 2501;
char ozw_version_string[] = "1.4-2501-g5af6780-dirty";
