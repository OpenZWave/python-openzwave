#include "Defs.h"
uint16_t ozw_vers_major = 1;
uint16_t ozw_vers_minor = 4;
uint16_t ozw_vers_revision = 3428;
char ozw_version_string[] = "1.4-3428-g30567960-dirty";
